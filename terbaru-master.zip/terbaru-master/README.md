# dark fb
new dark FB

<img alt="Dark FB" src="https://github.com/darkfb/terbaru/blob/master/2019-08-17%20(2).png"/>

pkg install python2

pkg install git

pkg install curl

git clone https://github.com/darkfb/terbaru

cd terbaru

pip2 install -r requirements.txt

python2 dark.pyc
